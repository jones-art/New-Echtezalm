<?php include 'head.php';  ?>
<!-- Login Section -->
<section>
	<div class="form-back" data-aos="flip-down" data-aos-duration='2000'>
		<div class="white-text container">
			<h4> Welkom bij Fresh Smoked Salmon </h4>
			<p class="center">Al aangemeld? Hier inloggen </p>
			<div class="container">
				<!--  -->
			<form class="container">
				<div class="row container">
					<div class="col m6 s12 input-field">
						<input type="text" name="" class="white-text  browser-default input" placeholder="Voornaam">
					</div>

					<div class="col m6 s12 input-field">
						<input type="password" name=""  class="white-text browser-default input" placeholder="Achternaam">
					</div>

					<div class="col s12 input-field">
						<select  class="browser-default input">
							<option selected="" disabled="">land van verblijf</option>
							<option style="color: black;">Name</option>
						</select>
					</div>

					<div class="col m6 s12 input-field">
						<select style="border: 1px solid #fff; padding-left: 20px; background: transparent;color: white; width: 100%;" class="browser-default">
							<option selected="" disabled="">Geslacht</option>
							<option style="color: black;">Name</option>
						</select>
					</div>

					<div class="col m6 s12 input-field">
						<input type="text" name=""  class="browser-default white-text input" placeholder="Geboortedatum">
					</div>

					<div class="col s12 input-field">
						<input type="text" name=""  class="browser-default white-text input" placeholder="Jouw email">
					</div>

					<div class="col s12 input-field">
						<input type="text" name=""  class="browser-default white-text input" placeholder="Je wachtwoord">
					</div>

					<div class="col s12 input-field">
						<p>
							<label>
								<input type="checkbox" name=""><span>Ik ontvang graag het laatste Freshly Fish nieuws en weet wanneer de volgende visdoos verschijnt!</span>
							</label>
						</p>
					</div>

					<div class="col s12 input-field">
						<input type="submit" class="btn formbtn" value="Login">
					</div>

					

					<div c>
						
					</div>
				</div>			
			</form>

			</div>
		</div>
	</div>
	
</section>

<script type="text/javascript" src="js/jquery-3.5.1.min.js"></script>
<script type="text/javascript" src="js/materialize.min.js"></script>
<!-- Animation on Scroll -->
<script type="text/javascript" src="js/aos.min.js"></script>
<!-- Flip Card -->
<script type="text/javascript" src="js/flip.min.js"></script>

<script type="text/javascript">
	AOS.init();
	$('.carousel').carousel({
    fullWidth: true,
    indicators: true
});

var autoplay = true;

setInterval(function() { 
    if(autoplay) $('.carousel.carousel-slider').carousel('next');
}, 4500);


</script>
<?php include 'script.php' ?>
<!-- <input type="button" name="" class="btn planbtn" style="width: 100% " placeholder="Username" value="login"> -->
<!-- width: 492px; height: 50px; padding-left:20px; padding-top: 14px; padding-bottom: 14px; 
	<input type="text" name="" style="border:2px solid white; margin-top: 30px; " placeholder="Username">

				<input type="submit" class="btn planbtn" style="width: 100%; height: 50px;" value="login" name="">
-->