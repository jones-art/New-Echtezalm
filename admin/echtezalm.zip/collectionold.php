<?php include 'head.php' ?>
<section >
	<div class="carousel carousel-slider center">
    <div class="carousel-fixed-item center">	

      <h5>A Special Experience Of Taste And Tradition</h5>
        <div style="margin-top: 76px;">
          <a class="btn planbtn2">Get Started</a>
        <a class="btn planbtn">Collection</a>
    </div>
    </div>
    <div class="carousel-item carousel-img " href="#one!">
  
    </div>
    <div class="carousel-item carousel-img amber white-text" href="#two!">
      
    </div>
    <div class="carousel-item carousel-img green white-text" href="#three!">
      
    </div>
    <div class="carousel-item carousel-img blue white-text" href="#four!">
      
    </div>
  </div>
  </div>
</section>

<?php include 'script.php' ?>