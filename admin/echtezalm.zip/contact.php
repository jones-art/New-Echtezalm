<?php include 'head.php' ?>
<!-- Google Map -->
     <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyDKXKdHQdtqgPVl2HI2RnUa_1bjCxRCQo4&amp;callback=initMap"
    async defer></script>
<section>
	<div class="container">
		<h5 class="center" style="padding-bottom: 108px;">Contact Us</h5>
		<div class="row">
			<div class="col m5 s12 card black" >
				<h5>Keep in touch</h5>
				<p style="margin-bottom: 58px; color: white;">Reach out to us for any enquiry</p>
				<div class="row">
					<div class="col s12 input-field">
						<label for="name" style="padding-left: 20px;">Name <span class="red-text">*</span> </label>
						<input type="text" id="name" class="browser-default input" name="">
					</div>

					<div class="col s12 input-field">
						<label for="email" style="padding-left: 20px;">E-mail <span class="red-text">*</span> </label>
						<input type="email" id="email" class="browser-default input" name="">
					</div>

					<div class="col s12 input-field">
						<label for="phone" style="padding-left: 20px;">Phone <span class="red-text">*</span> </label>
						<input type="text" id="phone" class="browser-default input" name="">
					</div>

					<div class="col s12 input-field">
						<label for="phone" style="padding-left: 20px;">Message <span class="red-text">*</span> </label>
						<textarea class="browser-default input" style="height: 111px;"></textarea>
					</div>

					<div class="row">
						<div class="col s5 left input-field upload">
						<label for="uploadImg"> <i class="fas fa-cloud-upload-alt"></i>Upload file</label>
		  					<input type="file" id="uploadImg" name="upload">
						</div>

						<div class="col s6 input-field">
							<!-- <input type="submit" class="btn planbtn" name=""> -->
							<button class="btn planbtn" type="submit">Send Message</button>
						</div>
					</div>
				</div>
			</div>

			<!-- Map Div Start From Here -->
			<div class="col s12 m7 right card black" id="style-map" style="height: 552px; width: 563px; margin-top: 55px;"></div>

		</div>
	</div>
</section>

<hr style="width:100%; ">

<section>
	<div class="container">
		<div class="row">
			<div class="col m6 s12 card black white-text">
				<div class="row">
					<div class="col s1 black" style="padding-top: 24px;">
            <img src="images/icon/location.png">      
          </div>
          
          <div class="col s11" style="padding-top: 56px;">
            <p style="color: #DAC08E;">Location</p>
            <p style="margin-top: 10px;">359  Frankenroda Rd, Mihla, Deutche.</p>
          </div>
				</div>
			</div>

      <div class="col s12 m3 card black white-text">
        <div class="row">
          <div class="col s2 black" style="padding-top: 24px;">
            <img src="images/icon/phone.png">      
          </div>
          
          <div class="col s10" style="padding-top: 56px;">
            <p style="color: #DAC08E;">Phone</p>
            <p>+32 011 240 193</p>
          </div>
        </div>
      </div>

      <div class="col s12 m3 card black white-text">
        <div class="row">
          <div class="col s2 black" style="padding-top: 24px;">
            <img src="images/icon/mail.png">      
          </div>
          
          <div class="col s10" style="padding-top: 56px;">
            <p style="color: #DAC08E;">E-mail</p>
            <p>Johndoe@nomail.com</p>
          </div>
        </div>
      </div>

		</div>
	</div>
</section>


<?php include 'footer.php' ?>
<script type="text/javascript">
	var map;
      function initMap() {
        let myLatLng = {lat: 52.1326, lng: 5.2913}
var map = new google.maps.Map(document.getElementById('style-map'), {
          center: myLatLng,
          zoom: 4,
          styles: [
            {elementType: 'geometry', stylers: [{color: '#242f3e'}]},
            {elementType: 'labels.text.stroke', stylers: [{color: '#242f3e'}]},
            {elementType: 'labels.text.fill', stylers: [{color: '#746855'}]},
            {
              featureType: 'administrative.locality',
              elementType: 'labels.text.fill',
              stylers: [{color: '#d59563'}]
            },
            {
              featureType: 'poi',
              elementType: 'labels.text.fill',
              stylers: [{color: '#d59563'}]
            },
            {
              featureType: 'poi.park',
              elementType: 'geometry',
              stylers: [{color: '#263c3f'}]
            },
            {
              featureType: 'poi.park',
              elementType: 'labels.text.fill',
              stylers: [{color: '#6b9a76'}]
            },
            {
              featureType: 'road',
              elementType: 'geometry',
              stylers: [{color: '#38414e'}]
            },
            {
              featureType: 'road',
              elementType: 'geometry.stroke',
              stylers: [{color: '#212a37'}]
            },
            {
              featureType: 'road',
              elementType: 'labels.text.fill',
              stylers: [{color: '#9ca5b3'}]
            },
            {
              featureType: 'road.highway',
              elementType: 'geometry',
              stylers: [{color: '#746855'}]
            },
            {
              featureType: 'road.highway',
              elementType: 'geometry.stroke',
              stylers: [{color: '#1f2835'}]
            },
            {
              featureType: 'road.highway',
              elementType: 'labels.text.fill',
              stylers: [{color: '#f3d19c'}]
            },
            {
              featureType: 'transit',
              elementType: 'geometry',
              stylers: [{color: '#2f3948'}]
            },
            {
              featureType: 'transit.station',
              elementType: 'labels.text.fill',
              stylers: [{color: '#d59563'}]
            },
            {
              featureType: 'water',
              elementType: 'geometry',
              stylers: [{color: '#17263c'}]
            },
            {
              featureType: 'water',
              elementType: 'labels.text.fill',
              stylers: [{color: '#515c6d'}]
            },
            {
              featureType: 'water',
              elementType: 'labels.text.stroke',
              stylers: [{color: '#17263c'}]
            }
          ]
        });

  var marker = new google.maps.Marker({
          position: myLatLng,
          map: map,
          icon: 'images/cart.png'
        });
		
		
      }
   </script>

