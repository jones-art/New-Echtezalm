<?php include 'head.php' ?>


<!-- Description Section Start -->
<section style="padding-top: 59px;background: #0F0F0F;"> data-aos="flip-up" data-aos-duration="2000">
	<div class="container">
		<div class="row"  data-aos="flip-down" data-aos-duration="1000">
			<div class="col l8 s12 m4 white-text card" id="black" style="background: #0F0F0F">
				<div class="card-image">
					<img src="images/blog/blog-1.png"  style="margin-top:0px;">
					<div class="white-text card-title center">
                        <h5 class="blogTit">Sept 22, 2020</h5>
                        <p class="blogPar"> 11 Verrassende gezondheidsvoordelen van zalm en waarom je het dagelijks zou moeten eten</p>
                    </div>
				</div>
			</div>

			<div class="col l4 m12 s12 right-align">
              <div class="card"  style="margin-bottom:0px;background: #3A3A3A;">
                <div class="card-image">
                  <img src="images/blog/blog.png" style="margin-top:0px">
                </div>
                <div class="card-content " style="padding-bottom:28px;padding-left:20px">
                    <h6 class="blogTit">Sept 22, 2020</h6>
                    <p class="blogPar white-text" style="line-height:26.66px;font-size:18px"> 11 Verrassende gezondheidsvoordelen van zalm en waarom je het dagelijks zou moeten eten</p>
                </div>
               </div>
			</div>
		</div>

		<div class="row" data-aos="flip-down" data-aos-duration="1000" style="margin-top:22px">
			<!-- First Column blog -->
			<div class="col l4 s12 m4 white-text" id="black" style="marging-right:62px;margin-top:28px">
              <div class="card"  style="margin-bottom:0px;background: #3A3A3A;">
                <div class="card-image">
                  <img src="images/blog/blog.png" style="margin-top:0px">
                </div>
                <div class="card-content " style="padding-bottom:28px;padding-left:20px;padding-right:30px">
                    <h6 class="blogTit">Sept 22, 2020</h6>
                    <p class="blogPar white-text" style="line-height:26.66px;font-size:18px"> 11 Verrassende gezondheidsvoordelen van zalm en waarom je het dagelijks zou moeten eten</p>
                </div>
               </div>
			</div>
			<div class="col l4 s12 m4 white-text" id="black" style="marging-right:62px;margin-top:28px">
              <div class="card"  style="margin-bottom:0px;background: #3A3A3A;">
                <div class="card-image">
                  <img src="images/blog/blog-2.png" style="margin-top:0px">
                </div>
                <div class="card-content " style="padding-bottom:28px;padding-left:20px;padding-right:30px">
                    <h6 class="blogTit">Sept 22, 2020</h6>
                    <p class="blogPar white-text" style="line-height:26.66px;font-size:18px"> 11 Verrassende gezondheidsvoordelen van zalm en waarom je het dagelijks zou moeten eten</p>
                </div>
               </div>
			</div>
			<div class="col l4 s12 m4 white-text" id="black" style="marging-right:62px;margin-top:28px">
              <div class="card"  style="margin-bottom:0px;background: #3A3A3A;">
                <div class="card-image">
                  <img src="images/blog/blog-2.png" style="margin-top:0px">
                </div>
                <div class="card-content " style="padding-bottom:28px;padding-left:20px;padding-right:30px">
                    <h6 class="blogTit">Sept 22, 2020</h6>
                    <p class="blogPar white-text" style="line-height:26.66px;font-size:18px"> 11 Verrassende gezondheidsvoordelen van zalm en waarom je het dagelijks zou moeten eten</p>
                </div>
               </div>
			</div>
            <!-- First Row of the blog -->
            
            <!-- Second colun Blog-->
			<div class="col l4 s12 m4 white-text" id="black" style="marging-right:62px;margin-top:28px">
              <div class="card"  style="margin-bottom:0px;background: #3A3A3A;">
                <div class="card-image">
                  <img src="images/blog/blog-2.png" style="margin-top:0px">
                </div>
                <div class="card-content " style="padding-bottom:28px;padding-left:20px;padding-right:30px">
                    <h6 class="blogTit">Sept 22, 2020</h6>
                    <p class="blogPar white-text" style="line-height:26.66px;font-size:18px"> 11 Verrassende gezondheidsvoordelen van zalm en waarom je het dagelijks zou moeten eten</p>
                </div>
               </div>
			</div>
			<div class="col l4 s12 m4 white-text" id="black" style="marging-right:62px;margin-top:28px">
              <div class="card"  style="margin-bottom:0px;background: #3A3A3A;">
                <div class="card-image">
                  <img src="images/blog/blog.png" style="margin-top:0px">
                </div>
                <div class="card-content " style="padding-bottom:28px;padding-left:20px;padding-right:30px">
                    <h6 class="blogTit">Sept 22, 2020</h6>
                    <p class="blogPar white-text" style="line-height:26.66px;font-size:18px"> 11 Verrassende gezondheidsvoordelen van zalm en waarom je het dagelijks zou moeten eten</p>
                </div>
               </div>
			</div>
			<div class="col l4 s12 m4 white-text" id="black" style="marging-right:62px;margin-top:28px">
              <div class="card"  style="margin-bottom:0px;background: #3A3A3A;">
                <div class="card-image">
                  <img src="images/blog/blog-2.png" style="margin-top:0px">
                </div>
                <div class="card-content " style="padding-bottom:28px;padding-left:20px;padding-right:30px">
                    <h6 class="blogTit">Sept 22, 2020</h6>
                    <p class="blogPar white-text" style="line-height:26.66px;font-size:18px"> 11 Verrassende gezondheidsvoordelen van zalm en waarom je het dagelijks zou moeten eten</p>
                </div>
               </div>
			</div>
            <!-- First Row of the blog -->
            
            <!-- Thirdcolun Blog-->
			<div class="col l4 s12 m4 white-text" id="black" style="marging-right:62px;margin-top:28px">
              <div class="card"  style="margin-bottom:0px;background: #3A3A3A;">
                <div class="card-image">
                  <img src="images/blog/blog-2.png" style="margin-top:0px">
                </div>
                <div class="card-content " style="padding-bottom:28px;padding-left:20px;padding-right:30px">
                    <h6 class="blogTit">Sept 22, 2020</h6>
                    <p class="blogPar white-text" style="line-height:26.66px;font-size:18px"> 11 Verrassende gezondheidsvoordelen van zalm en waarom je het dagelijks zou moeten eten</p>
                </div>
               </div>
			</div>
			<div class="col l4 s12 m4 white-text" id="black" style="marging-right:62px;margin-top:28px">
              <div class="card"  style="margin-bottom:0px;background: #3A3A3A;">
                <div class="card-image">
                  <img src="images/blog/blog.png" style="margin-top:0px">
                </div>
                <div class="card-content " style="padding-bottom:28px;padding-left:20px;padding-right:30px">
                    <h6 class="blogTit">Sept 22, 2020</h6>
                    <p class="blogPar white-text" style="line-height:26.66px;font-size:18px"> 11 Verrassende gezondheidsvoordelen van zalm en waarom je het dagelijks zou moeten eten</p>
                </div>
               </div>
			</div>
			<div class="col l4 s12 m4 white-text" id="black" style="marging-right:62px;margin-top:28px">
              <div class="card"  style="margin-bottom:0px;background: #3A3A3A;">
                <div class="card-image">
                  <img src="images/blog/blog.png" style="margin-top:0px">
                </div>
                <div class="card-content " style="padding-bottom:28px;padding-left:20px;padding-right:30px">
                    <h6 class="blogTit">Sept 22, 2020</h6>
                    <p class="blogPar white-text" style="line-height:26.66px;font-size:18px"> 11 Verrassende gezondheidsvoordelen van zalm en waarom je het dagelijks zou moeten eten</p>
                </div>
               </div>
			</div>
            <!-- Third Row of the blog -->

		</div>
        
    <!-- Pagination goes here-->
      <ul class="pagination center" style="margin-top:144px;margin-bottom:47px">
        <li class=""><a href="#!" ><img src="images/icon/chevron_left.png" style="margin-right: 27px;"></a></li>
        <li class="waves-effect"><a href="#!" class="white-text btn black">1</a></li>
        <li class="waves-effect"><a href="#!" class="white-text btn black">2</a></li>
        <li class="waves-effect"><a class="white-text btn black" href="#!">3</a></li>
        <li class="waves-effect"><a class="white-text btn black"  href="#!">4</a></li>
        <li class="waves-effect"><a class="white-text btn black"  href="#!">5</a></li>
        <li class="waves-effect"><a class="white-text btn black"  href="#!">6</a></li>
        <li class="waves-effect"><a class="white-text btn black"  href="#!">7</a></li>
        <li class="waves-effect"><a class="white-text btn black"  href="#!">8</a></li>
        <li class="waves-effect"><a class="white-text btn black"  href="#!">9</a></li>
        <li class="waves-effect"><a class="white-text btn black"  href="#!"> 10</a></li>
        <li class=""><a href="#!"><img src="images/icon/chevron_right.png" style="margin-left: 27px;"></a></li>
      </ul>

    <!--Pagination ends here-->
	</div>
    <div class="container" style="height:136px"></div>
</section>
<!-- Description Section End -->

<?php include ('footer.php'); ?>

<script type="text/javascript" src="js/jquery-3.5.1.min.js"></script>
<script type="text/javascript" src="js/materialize.min.js"></script>
<!-- Animation on Scroll -->
<script type="text/javascript" src="js/aos.min.js"></script>
<!-- Flip Card -->
<script type="text/javascript" src="js/flip.min.js"></script>

<script type="text/javascript">
	AOS.init();
	$('.carousel').carousel({
    fullWidth: true,
    indicators: true
});

var autoplay = true;

setInterval(function() { 
    if(autoplay) $('.carousel.carousel-slider').carousel('next');
}, 4500);


</script>
<?php include 'script.php' ?>
