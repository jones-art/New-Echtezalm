<footer class="container-fluid" style="background: black; color: white;">
	<div class="container" style="height:157px"></div>
<div class="container">
		<div class="row">
		<div class="col l3 s12 m6">
			<h4 style="font-family:playfair" class="text-white font-weight-bold">Verbind je met ons</h4>
			<img src="images/icon/arrow-right.png">
		</div>
		<div class="col l3 s12 m6">
		<h4 style="font-family:playfair" class="text-white font-weight-bold">Sitemap</h4>
    <div>
      <p><a href="" class="text-muted"> Huis</a> </p>
      <p><a href="" class="text-muted"> Online winkel</a> </p>
      <p><a href="" class="text-muted"> Voor zaken</a> </pp>
      <p><a href="" class="text-muted"> Over ons</a> </p>
      <p><a href="" class="text-muted"> Blog</a> </p>
      <p><a href="" class="text-muted"> Betalen</a> </p>
      <p><a href="" class="text-muted"> Mijn rekening</a> </p>
      <p><a href="" class="text-muted"> Winkelmand</a> </p>   
    </div>

	</div>
	<div class="col l3 s12 m6">
			<h4 style="font-family:playfair" class="text-white font-weight-bold">Blog</h4>
			<p class="text-muted">Lancering van nieuwe website</p>
		</div>
	<div class="col l3 s12 m6">
			<h4 style="font-family:playfair" class="text-white font-weight-bold">Social media</h4>
			<div>
				<img src="images/icon/facebook.png"> &nbsp &nbsp
				<img src="images/icon/linkedin.png">
			</div>
		</div>
	</div>
</div>

<div class="container" style="height:89px"></div>
</footer>
<script type="text/javascript" src="js/jquery-3.5.1.min.js"></script>
<script type="text/javascript" src="js/materialize.min.js"></script>
<!-- Animation on Scroll -->
<script type="text/javascript" src="js/aos.min.js"></script>
<!-- Flip Card -->
<script type="text/javascript" src="js/flip.min.js"></script>

<script type="text/javascript">
	AOS.init();
	$('.carousel').carousel({
    fullWidth: true,
    indicators: true
});

var autoplay = true;

setInterval(function() { 
    if(autoplay) $('.carousel.carousel-slider').carousel('next');
}, 4500);


</script>
<?php include 'script.php' ?>
