<?php include 'head.php' ?>
<!-- Red Navbra -->
<section>
  <nav class="black nav-center" role="navigation" style="height: 45px;">
    <div class="nav-wrapper menu container-fluid " style="background: #F44336;margin-bottom: 5px;">
    	<h4 class="navRed center">03d : 03h : 24m till next shipping </h4>
    </div>
  </nav>
</section>

<section >
	<div class="carousel carousel-slider" style="height: 658px;">
    <div class="carousel-fixed-item center">	

      <h5 data-aos="flip-up" data-aos-duration="2000">A Special Experience Of Taste And Tradition</h5>
        <div style="margin-top: 76px; margin-bottom: 157px;" data-aos="flip-right" data-aos-duration="1000">
          <a class="btn planbtn2">Get Started</a>
        <a class="btn planbtn">Collection</a>
        
    </div>
    </div>
    <!-- <div><a class="btn-floating white"><i class="material-icons black-text">add</i></a></div> -->
    <div class="carousel-item carousel-img " href="#one!">
  
    </div>
    <div class="carousel-item carousel-img amber white-text" href="#two!">
      
    </div>
    <div class="carousel-item carousel-img green white-text" href="#three!">
      
    </div>
    <div class="carousel-item carousel-img blue white-text" href="#four!">
      
    </div>
  </div>
  
</section>

<!-- Carousel Section End -->

<!-- Description Section Start -->
<section style="padding-top: 59px;">
	<div class="container">
		<div class="row">
			<div class="col l6 s12 m12 white-text" data-aos='flip-right' data-aos-duration='1000' style="margin-top: 59px;">
				<h5>Echte zalm; een delicatesse of een mooi gelegenheidscadeau.</h5>
				<div class="desc" style="margin-top: 33px; margin-right: 30px;">
					Deze traditioneel gerookte zalm is een bijzondere beleving van smaak en traditie. Een zalm die anders wordt gerookt dan de koud gerookte zalm die je kent van speciaalzaken of supermarkten. Deze zalm is anders, lekkerder en exclusief. De traditionele manier van roken en stomen houdt in dat de zalm op de huid wordt gerookt bij een temperatuur van 80 graden, waardoor zowel de structuur als de smaak van de zalm behouden blijft. Dit maakt de zalm tot een smakelijke, gezonde traktatie en een delicatesse van hoge kwaliteit voor iedereen die van sfeer en gezelligheid houdt; de Bourgondische manier van leven.
				</div>
			</div>

			<div class="col l6 m12 s12 right-align" data-aos='flip-left' data-aos-duration='1000' style="height: 347px; margin-top: 68px;">
				<img src="images/description.png" class="responsive-img">
			</div>
		</div>
	</div>
</section>

<!-- Description Section End -->

<!-- Collection Section Starts -->
<section style="margin-top: 72px;">
	<div class="container">
		<h5 class="center">Onze collectie</h5>
		<p class="white-text center">Onze exclusieve collectie speciaal voor jou</p>
		<div class="row"  data-aos="flip-down" data-aos-duration="1000">
			<!-- Black Edition -->
			<div class="col l4 s12 m4 white-text card black" id="black">
				<div class="card-image">
					<img src="images/black-edition.png">
					<div class="white-text card-title center">Black Edition</div>
				</div>
			</div>
			<!-- Black Edition End Here -->

			<!-- Dutch Edition -->
			<div class="col l4 s12 m4 white-text card black" id="dutch">
				<div class="card-image">
					<img src="images/dutch-edition.png">
					<div class="white-text card-title center-align">Dutch Edition</div>
				</div>
			</div>
			<!-- Dutch Edition End Here -->

			<!-- Classic Edition -->
			<div class="col l4 s12 m4 white-text card black" id="classic">
				<div class="card-image">
					<img src="images/classic-edition.png">
					<div class="white-text card-title center-align">Classic Edition</div>
				</div>		
			</div>
			<!-- Classic Edition Ends Here -->
		</div>
	</div>
</section>
<!-- collection section ends here -->
<!-- Webshop Section Starts -->
<section >
	<div class="container"  style="margin-top: 83px;">>
		<h5 class="center">Bekijk onze WebShop</h5>
		<p class="white-text center">Hier kunt u uw verse gerookte zalm bestellen</p>
	<div class="row" style="margin-top:72px">
		<div class="col s6 l3 m6" data-aos="flip-right" data-aos-duration="1000">
	      <div class="card black"  style="border:solid 1px #fff;margin-bottom:0px">
	        <div class="card-image">
	          <img src="images/webshop.png" style="margin-top: 0px">
	        </div>
	        <div class="card-content" style="padding-bottom: 16px">
	        	<h6 class="white-text center">Product Name</h6>
	          	<h6 style="margin-bottom: 15px"> €39.95</h6>
	          	<a href="#"class="webBtn center">Voeg toe aan winkelkar</a>
	        </div>

	      </div>
		</div>

		<div class="col s6 l3 m6"  data-aos="flip-left" data-aos-duration="1000">
	      <div class="card black"  style="border:solid 1px #fff;margin-bottom:0px">
	        <div class="card-image">
	          <img src="images/webshop.png" style="margin-top: 0px">
	        </div>
	        <div class="card-content" style="padding-bottom: 16px">
	        	<h6 class="white-text center">Product Name</h6>
	          	<h6 style="margin-bottom: 15px"> €39.95</h6>
	          	<a href="#"class="webBtn center">Voeg toe aan winkelkar</a>
	        </div>

	      </div>
		</div>

		<div class="col s6 l3 m6"  data-aos="flip-right" data-aos-duration="1000">
	      <div class="card black"  style="border:solid 1px #fff;margin-bottom:0px">
	        <div class="card-image">
	          <img src="images/webshop.png" style="margin-top: 0px">
	        </div>
	        <div class="card-content" style="padding-bottom: 16px">
	        	<h6 class="white-text center">Product Name</h6>
	          	<h6 style="margin-bottom: 15px"> €39.95</h6>
	          	<a href="#"class="webBtn center">Voeg toe aan winkelkar</a>
	        </div>

	      </div>
		</div>

		<div class="col s6 l3 m6"  data-aos="flip-left" data-aos-duration="1000">
	      <div class="card black"  style="border:solid 1px #fff;margin-bottom:0px">
	        <div class="card-image">
	          <img src="images/webshop.png" style="margin-top: 0px">
	        </div>
	        <div class="card-content" style="padding-bottom: 16px">
	        	<h6 class="white-text center">Product Name</h6>
	          	<h6 style="margin-bottom: 15px"> €39.95</h6>
	          	<a href="#"class="webBtn center">Voeg toe aan winkelkar</a>
	        </div>

	      </div>
		</div>
	</div>

	</div>
</section>
<!-- Webshop ends here -->

<!-- How to use Section Starts -->
<section style="margin-top: 72px">
	<div class="container red" style="margin-top:27px"></div>
	<div class="container">
		<h5 class="center">Eenvoudige abonnementsgids</h5>
		<p class="white-text center">Inschrijven was nog nooit zo eenvoudig</p>
		  <div class="row"  data-aos="zoom-out" data-aos-duration="1000">
            <div class="col s6 l3 m6">
              <div class="center promo promo-example">
                <img src="images/icon/open.png"/>
                <h5 class="promo-caption">Inschrijven</h5>
                <hr class="hr">
                <p class="light center">Registreer om toegang te krijgen tot meer vanaf onze website</p>
              </div>
          </div>

            <div class="col s6 l3 m6">
              <div class="center promo promo-example">
                <img src="images/icon/sushi.png"/>
                <h5 class="promo-caption">Selecteer een collectie</h5>
                <hr class="hr">
                <p class="light center">We hebben een geweldige collectie zalmvissen, we hebben iets voor je</p>
              </div>
          </div>

            <div class="col s6 l3 m6">
              <div class="center promo promo-example">
               <img src="images/icon/fish.png"/>
                <h5 class="promo-caption">Verse salmons</h5>
                <hr class="hr">
                <p class="light center">We zorgen ervoor dat we alleen de meest verse salmons voor u leveren</p>
              </div>
          </div>

            <div class="col s6 l3 m6">
              <div class="center promo promo-example">
                <img src="images/icon/ride.png"/>
                <h5 class="promo-caption">Laat uw doos bezorgen</h5>
                <hr class="hr">
                <p class="light center">Laat je maandelijkse Box van Echte thuisbezorgen</p>
              </div>
          </div>
			<!-- Webshop coloums Ends Here -->
		</div>
	</div>
</section>
<!-- How to use ends here -->

<!-- Client Comment Section Starts -->
<section style="margin-top: 72px;background:#3A3A3A;">
	<div class="container" style="height:27px"></div>
	<div class="container"  data-aos="zoom-in" data-aos-duration="1000">
		<h5 class="center">Wat onze klanten denken</h5>
         <div class="center">
            <img src="images/icon/star.png">
            <img src="images/icon/star.png">
            <img src="images/icon/star.png">
            <img src="images/icon/star.png">
            <img src="images/icon/star.png">
          </div>
		<p class="white-text center" style="margin-bottom:23px">My favourite place to make order</p>
		<div class="container">
			<p class="center" style="color:#E8E8E8;"> Lorem ipsum dolor sit amet, consectetur adipiscing elit. Pulvinar arcu non a, fringilla mi donec vulputate. Quis in dignissim ac risus. Amet purus gravida massa venenatis. Diam viverra malesuada lacus, ante sed pharetra. Vitae cum ornare metus, vel, pharetra morbi eget vel.
			Massa sapien sed scelerisque ullamcorper ante id aliquam tortor et. Lectus mollis non vel quis eget mus.</p>
		</div>

		<div class="container">
			<h6 class="white-text center">Username</h6>
		</div>
			<!-- Blog coloums Ends Here -->
			<div class="container" style="height:77px"></div>
	</div>
</section>
<!-- Customer comment ends here -->

<!-- Blog Section Starts -->
<section style="margin-top: 72px;background:#0f0f0f">
	<div class="container">
		<h5>Blog</h5>
		<p class="white-text" style="margin-bottom:23px">Bekijk meer geweldige inhoud van ons</p>
		<div class="row"  data-aos="flip-left" data-aos-duration="1000">
	      <div class="col s12 l6 m6">
	          <div class="row">
	            <div class="col m2 center blogCol black">
	              <h5 class="bh6">20</h5>
	              <h6 class="bh6" style="margin-top:0px">AUG</h6>
	            </div>
	            <div class="col m10 ">
	                <p class="grey-text text-lighten-5 text-center">
	                44 gezondheidsvoordelen van het eten van zalm met Bruine rijst en het recept en de beste koks die er zijn.</p>
	            </div>
	          </div>     
	      </div>

	      <div class="col s12 l6 m6">
	          <div class="row">
	            <div class="col m2 center blogCol black">
	              <h5 class="bh6">20</h5>
	              <h6 class="bh6" style="margin-top:0px">AUG</h6>
	            </div>
	            <div class="col m10 ">
	                <p class="grey-text text-lighten-5 text-center">
	                44 gezondheidsvoordelen van het eten van zalm met Bruine rijst en het recept en de beste koks die er zijn.</p>
	            </div>
	          </div>     
	      </div>

	      <div class="col s12 l6 m6">
	          <div class="row">
	            <div class="col m2 center blogCol black">
	              <h5 class="bh6">20</h5>
	              <h6 class="bh6" style="margin-top:0px">AUG</h6>
	            </div>
	            <div class="col m10 ">
	                <p class="grey-text text-lighten-5 text-center">
	                44 gezondheidsvoordelen van het eten van zalm met Bruine rijst en het recept en de beste koks die er zijn.</p>
	            </div>
	          </div>     
	      </div>

	      <div class="col s12 l6 m6">
	          <div class="row">
	            <div class="col m2 center blogCol black">
	              <h5 class="bh6">20</h5>
	              <h6 class="bh6" style="margin-top:0px">AUG</h6>
	            </div>
	            <div class="col m10 ">
	                <p class="grey-text text-lighten-5 text-center">
	                44 gezondheidsvoordelen van het eten van zalm met Bruine rijst en het recept en de beste koks die er zijn.</p>
	            </div>
	          </div>     
	      </div>

	      <div class="col s12 l6 m6">
	          <div class="row">
	            <div class="col m2 center blogCol black">
	              <h5 class="bh6">20</h5>
	              <h6 class="bh6" style="margin-top:0px">AUG</h6>
	            </div>
	            <div class="col m10 ">
	                <p class="grey-text text-lighten-5 text-center">
	                44 gezondheidsvoordelen van het eten van zalm met Bruine rijst en het recept en de beste koks die er zijn.</p>
	            </div>
	          </div>     
	      </div>

	      <div class="col s12 l6 m6">
	          <div class="row">
	            <div class="col m2 center blogCol black">
	              <h5 class="bh6">20</h5>
	              <h6 class="bh6" style="margin-top:0px">AUG</h6>
	            </div>
	            <div class="col m10 ">
	                <p class="grey-text text-lighten-5 text-center">
	                44 gezondheidsvoordelen van het eten van zalm met Bruine rijst en het recept en de beste koks die er zijn.</p>
	            </div>
	          </div>     
	      </div>
		</div>
	</div>
</section>
<!-- Blog post ends here -->


<?php include ('footer.php'); ?>

