<?php include 'head.php';  ?>
<!-- Login Section -->
<section>
	<div class="form-back" data-aos="flip-down" data-aos-duration='2000'>
		<div class="white-text container">
			<h4> Welkom terug </h4>
			<p class="center">Nieuw bij Echtezalm? <a href="register" style="color:#AD976E;">Registreer hier</a></p>
			<div class="container">
				
			<form class="container">
				<div class="row container">
					<div class="col s12 input-field">
						<input type="text" name="" class="white-text browser-default input" placeholder="Username">
					</div>

					<div class="col s12 input-field">
						<input type="password" name=""  class="white-text icon_prefix browser-default input" placeholder="Password">
						<i class="prefix"><img src="images/icon/globe.png"></i>
					</div>

					<div class="col s12 input-field">
						<input type="submit" class="btn formbtn" value="Login">
					</div>

					<div class="col s12">
						<p class="right" ><a href="register" style="color:#AD976E; padding-left: 20px;">Wachtwoord vergeten?</a></p>
						<p style="padding-top: 44px;">Door verder te gaan accepteert u onze 
						<br><span style="color:#AD976E;">Gebruiksvoorwaarden en Privacybeleid.</span></p>
					</div>

					<div c>
						
					</div>
				</div>			
			</form>

			</div>
		</div>
	</div>
	
</section>

<script type="text/javascript" src="js/jquery-3.5.1.min.js"></script>
<script type="text/javascript" src="js/materialize.min.js"></script>
<!-- Animation on Scroll -->
<script type="text/javascript" src="js/aos.min.js"></script>
<!-- Flip Card -->
<script type="text/javascript" src="js/flip.min.js"></script>

<script type="text/javascript">
	AOS.init();
	$('.carousel').carousel({
    fullWidth: true,
    indicators: true
});

var autoplay = true;

setInterval(function() { 
    if(autoplay) $('.carousel.carousel-slider').carousel('next');
}, 4500);


</script>
<?php include 'script.php' ?>
<!-- <input type="button" name="" class="btn planbtn" style="width: 100% " placeholder="Username" value="login"> -->
<!-- width: 492px; height: 50px; padding-left:20px; padding-top: 14px; padding-bottom: 14px; 
	<input type="text" name="" style="border:2px solid white; margin-top: 30px; " placeholder="Username">

				<input type="submit" class="btn planbtn" style="width: 100%; height: 50px;" value="login" name="">
-->