<!DOCTYPE html>
<html>
  <head>
  <title>Welcome to ::| echtezalm</title>

    <!--Import materialize.css-->
    <link
      type="text/css"
      rel="stylesheet"
      href="css/materialize.min.css"
    />
    <!-- Custom CSS -->
    <link type="text/css" rel="stylesheet" href="css/style.css" />
  

    <!-- Google fonts -->
    <link rel="stylesheet" type="text/css" href="css/poppins.css">
    <link rel="stylesheet" type="text/css" href="css/playfair.css">

    <!-- Animation on Scroll -->
    <link href="css/aos.min.css" rel="stylesheet">

</head>
<!-- Big Nav Head -->
<nav class="d-flex">
    <div class="nav-wrapper container">
      <a href="#" data-target="mobile-demo" class="sidenav-trigger" style="padding-top: 31px;"><img src="images/icon/menu.png"></a>
      <a href="#" class="brand-logo center"><img src="images/logo-white.png" class="responsive-img"></a>
      <ul id="nav-mobile" class="right">
        <li><a href="badges.html"><img src="images/cart.png"></a></li>
        
      </ul>
    </div>
  </nav>

  <!-- Big nav Head Stop -->

  <!-- Menu Nav -->

  <nav class="hide-on-med-and-down black nav-center" role="navigation">
    <div class="nav-wrapper menu container-fluid ">
      <ul class="" id="menu">
        <li class="">
          <a class="active bt" id="home" href="index">Home </a>
        </li>
        <li> <a href="collection" id="col" class="bt">Collection</a></li>
        <li> <a href="webshop" class="bt">Web Shop</a></li>
        <li><a href="aboutUs" class="bt">About Us</a></li>
        <li><a href="blog" class="bt">Blog</a></li>
        <li><a href="contact" class="bt">Contact</a></li>
        <li class="dropdown">
          <a class="dropdown-trigger" href="#!" data-target="account">
           My Account
          </a>
        </li>
        <li><a href="" class="bt"> DE</a></li>
        <!-- <i><img src="images/icon/globe.png"></i> -->
      </ul>
    </div>
  </nav>

  <ul class="sidenav" id="mobile-demo">
    <li><a href="sass.html">Sass</a></li>
    <li><a href="badges.html">Components</a></li>
    <li><a href="collapsible.html">Javascript</a></li>
    <li><a href="mobile.html">Mobile</a></li>
  </ul>

<!-- Dropdown Structure -->
<ul id="account" class="dropdown-content right" style="background: black;">
  <li ><a class="" href="login" style="color: white;" >Login</a></li><br>
  <li ><a class="" href="register.php" style="color: white;">Register</a></li>
</ul>

